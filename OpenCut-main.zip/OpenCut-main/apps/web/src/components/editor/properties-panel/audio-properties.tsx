import { MediaElement } from "@/types/timeline";

export function AudioProperties({ element }: { element: MediaElement }) {
  return <div className="space-y-4 p-5">Audio properties</div>;
}